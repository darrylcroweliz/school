### ASST Information
* [Incubator Project](#)
* [Version 1.0](#)

### Social Links & Downloads
* [Video: How to install ASST on Ubuntu](https://www.youtube.com/watch?v=XrAB8_BHxfo&ab_channel=TarikSeyceri)
* [Video: How to install ASST on MacOSX](https://www.youtube.com/watch?v=IThRZEQVa7M&ab_channel=TarikSeyceri)
* [Video: How to install ASST on Windows](https://www.youtube.com/watch?v=FKxDa3zYz1E&ab_channel=TarikSeyceri)
* [Author's GitHub](https://github.com/TarikSeyceri)
* [Author's LinkedIn](https://www.linkedin.com/in/tarikseyceri/)
* [Author's Instagram](https://www.instagram.com/tarik.seyceri/?hl=en)

### Code Repository
* [OWASP ASST Github Repo](https://github.com/OWASP/ASST)
