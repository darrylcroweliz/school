#!/bin/sh
echo Welcome to OWASP ASST
node main.js
